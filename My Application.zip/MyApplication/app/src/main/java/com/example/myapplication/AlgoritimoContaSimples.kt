package com.example.myapplication

class AlgoritimoContaSimples {

    fun testConta(num1:Double, num2:Double ):Double{

        return num1 + num2
    }

}